import React, { useEffect, useRef } from 'react';
import {
  computeGatedAudioEnvelope,
  computeRingHarmonics,
  computeVoiceOrbDynamics,
  type JarvisState,
} from '../utils/jarvisEngine';

interface JarvisCoreCanvasProps {
  state: JarvisState;
  reducedMotion: boolean;
  micAnalyserRef?: React.MutableRefObject<AnalyserNode | null>;
  playbackAnalyserRef?: React.MutableRefObject<AnalyserNode | null>;
  simulatedVoiceEnergyRef?: React.MutableRefObject<number>;
  onRingClick: () => void;
}

interface SparseParticle {
  xNorm: number;
  yNorm: number;
  vx: number;
  vy: number;
  size: number;
  phase: number;
  isCyan: boolean;
}

export const JarvisCoreCanvas: React.FC<JarvisCoreCanvasProps> = ({
  state,
  reducedMotion,
  micAnalyserRef,
  playbackAnalyserRef,
  simulatedVoiceEnergyRef,
  onRingClick,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stateRef = useRef<{ state: JarvisState; reducedMotion: boolean }>({
    state,
    reducedMotion,
  });
  const smoothedEnvelopeRef = useRef<number>(0);

  useEffect(() => {
    stateRef.current = { state, reducedMotion };
  }, [state, reducedMotion]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let timerId = 0;
    let rafId = 0;
    const startTime = performance.now();
    const freqBins = new Uint8Array(64);

    // Sparse particles floating inside the lower crescent (inspired by the reference animation)
    const particles: SparseParticle[] = Array.from({ length: 28 }, (_, idx) => ({
      xNorm: ((idx * 37) % 100) / 100 - 0.5,
      yNorm: 0.12 + (((idx * 23) % 70) / 100) * 0.62,
      vx: (((idx * 19) % 40) - 20) * 0.0006,
      vy: -(0.0016 + ((idx * 13) % 25) * 0.00014),
      size: 1.0 + (idx % 3) * 0.65,
      phase: (idx / 28) * Math.PI * 2,
      isCyan: idx % 4 === 0,
    }));

    const handleResize = () => {
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.max(260, Math.round(rect.width * dpr));
      canvas.height = Math.max(260, Math.round(rect.height * dpr));
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    const render = (now: number) => {
      const elapsed = (now - startTime) / 1000;
      const { state: curState, reducedMotion: isReduced } = stateRef.current;

      // Sample real microphone or playback audio analyser with noise gating
      let bands = {
        rawRms: 0,
        gatedEnergy: 0,
        lowBand: 0,
        midBand: 0,
        highBand: 0,
      };

      const activeAnalyser =
        curState === 'listening'
          ? micAnalyserRef?.current
          : curState === 'speaking'
          ? playbackAnalyserRef?.current
          : null;

      if (activeAnalyser) {
        activeAnalyser.getByteFrequencyData(freqBins);
        bands = computeGatedAudioEnvelope(freqBins, smoothedEnvelopeRef.current, 0.06);
        smoothedEnvelopeRef.current = bands.gatedEnergy;
      } else if (curState === 'speaking') {
        const simLevel =
          simulatedVoiceEnergyRef?.current ??
          0.35 +
            Math.abs(Math.sin(elapsed * 6.4)) * 0.34 +
            Math.abs(Math.cos(elapsed * 10.8)) * 0.18;
        const target = Math.min(0.88, Math.max(0.14, simLevel));
        smoothedEnvelopeRef.current += (target - smoothedEnvelopeRef.current) * 0.28;
        bands = {
          rawRms: smoothedEnvelopeRef.current,
          gatedEnergy: smoothedEnvelopeRef.current,
          lowBand: smoothedEnvelopeRef.current * 0.9,
          midBand: smoothedEnvelopeRef.current,
          highBand: smoothedEnvelopeRef.current * 0.7,
        };
      } else if (curState === 'listening') {
        // Gentle reactive baseline when mic stream is silent/pending
        const simMic =
          simulatedVoiceEnergyRef?.current ??
          0.16 + Math.abs(Math.sin(elapsed * 3.8)) * 0.18;
        smoothedEnvelopeRef.current += (simMic - smoothedEnvelopeRef.current) * 0.22;
        bands = {
          rawRms: smoothedEnvelopeRef.current,
          gatedEnergy: smoothedEnvelopeRef.current,
          lowBand: smoothedEnvelopeRef.current * 0.85,
          midBand: smoothedEnvelopeRef.current * 0.95,
          highBand: smoothedEnvelopeRef.current * 0.6,
        };
      } else {
        smoothedEnvelopeRef.current *= 0.85;
        bands.gatedEnergy = Number(smoothedEnvelopeRef.current.toFixed(4));
      }

      const dynamics = computeVoiceOrbDynamics(curState, bands.gatedEnergy);
      const timeFactor = isReduced ? elapsed * 0.15 : elapsed;

      const width = canvas.width;
      const height = canvas.height;
      const cx = width / 2;
      const cy = height / 2;
      // Ring radius (~260-320px diameter) with generous canvas margin so ribbons and glow never clip
      const ringRadius = Math.min(width, height) * 0.30 * dynamics.orbScale;

      ctx.clearRect(0, 0, width, height);

      // Determine state-specific accent palette
      // Base spec palette: Violet #7855FF, Purple #B282FF, Blue #245FFF, Cyan #3ADFFF
      const isConfirming = curState === 'confirming';
      const isError = curState === 'error';
      const isSuccess = curState === 'success';
      const isThinking = curState === 'thinking';
      const isExecuting = curState === 'executing';
      const isTranscribing = curState === 'transcribing';

      // 1. Soft Outer Ambient Glow around the Hollow Ring
      ctx.save();
      const outerGlow = ctx.createRadialGradient(
        cx,
        cy,
        ringRadius * 0.72,
        cx,
        cy,
        ringRadius * 1.38
      );
      if (isError) {
        outerGlow.addColorStop(0, 'rgba(245, 158, 11, 0.22)');
        outerGlow.addColorStop(0.5, 'rgba(244, 63, 94, 0.12)');
      } else if (isConfirming) {
        outerGlow.addColorStop(0, 'rgba(245, 158, 11, 0.20)');
        outerGlow.addColorStop(0.5, 'rgba(120, 85, 255, 0.16)');
      } else if (isSuccess) {
        outerGlow.addColorStop(0, 'rgba(58, 223, 255, 0.28)');
        outerGlow.addColorStop(0.5, 'rgba(36, 95, 255, 0.16)');
      } else {
        outerGlow.addColorStop(0, `rgba(120, 85, 255, ${0.24 * dynamics.glowOpacity})`);
        outerGlow.addColorStop(0.5, `rgba(36, 95, 255, ${0.15 * dynamics.glowOpacity})`);
      }
      outerGlow.addColorStop(1, 'rgba(3, 5, 10, 0)');
      ctx.fillStyle = outerGlow;
      ctx.beginPath();
      ctx.arc(cx, cy, ringRadius * 1.38, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // 2. Dark Hollow Center (#03050A) with Brighter Lower Edge Blue/Violet Crescent
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, ringRadius * 0.97, 0, Math.PI * 2);
      ctx.clip();

      // Solid near-black hollow interior
      ctx.fillStyle = '#03050A';
      ctx.fillRect(cx - ringRadius, cy - ringRadius, ringRadius * 2, ringRadius * 2);

      // Brighter lower edge crescent illumination (matching reference video)
      const crescentGrad = ctx.createRadialGradient(
        cx,
        cy + ringRadius * 0.64,
        ringRadius * 0.04,
        cx,
        cy + ringRadius * 0.16,
        ringRadius * 0.96
      );
      if (isError) {
        crescentGrad.addColorStop(0, 'rgba(245, 158, 11, 0.48)');
        crescentGrad.addColorStop(0.45, 'rgba(225, 29, 72, 0.24)');
      } else if (isConfirming) {
        crescentGrad.addColorStop(0, 'rgba(245, 158, 11, 0.45)');
        crescentGrad.addColorStop(0.48, 'rgba(120, 85, 255, 0.34)');
      } else if (isSuccess) {
        crescentGrad.addColorStop(0, 'rgba(58, 223, 255, 0.56)');
        crescentGrad.addColorStop(0.48, 'rgba(36, 95, 255, 0.36)');
      } else {
        crescentGrad.addColorStop(
          0,
          `rgba(36, 95, 255, ${0.76 * dynamics.crescentIntensity})`
        );
        crescentGrad.addColorStop(
          0.42,
          `rgba(120, 85, 255, ${0.42 * dynamics.crescentIntensity})`
        );
        crescentGrad.addColorStop(
          0.74,
          `rgba(58, 223, 255, ${0.14 * dynamics.cyanAccentRatio})`
        );
      }
      crescentGrad.addColorStop(1, 'rgba(3, 5, 10, 0)');

      ctx.fillStyle = crescentGrad;
      ctx.fillRect(cx - ringRadius, cy - ringRadius, ringRadius * 2, ringRadius * 2);

      // 3. Sparse Floating Particles in the Lower Crescent
      if (!isReduced) {
        ctx.globalCompositeOperation = 'lighter';
        const activeCount = Math.min(particles.length, dynamics.emberCount);
        for (let i = 0; i < activeCount; i++) {
          const p = particles[i];
          const yShift = (p.yNorm + timeFactor * p.vy * (1 + bands.gatedEnergy * 1.4)) % 0.72;
          const normY = yShift < 0 ? yShift + 0.72 : yShift;
          const normX =
            p.xNorm +
            Math.sin(timeFactor * 1.6 + p.phase) * 0.1 * (0.4 + bands.midBand * 0.8);

          const px = cx + normX * ringRadius * 1.3;
          const py = cy + (0.14 + normY * 0.68) * ringRadius;

          if (Math.hypot(px - cx, py - cy) < ringRadius * 0.86) {
            const twinkle = 0.3 + 0.7 * Math.abs(Math.sin(timeFactor * 3.6 + p.phase * 2));
            const alpha = twinkle * (curState === 'idle' ? 0.28 : 0.85);
            const r = p.size * (1 + bands.highBand * 0.55);

            const pGlow = ctx.createRadialGradient(px, py, 0, px, py, r * 2.5);
            if (p.isCyan || isSuccess) {
              pGlow.addColorStop(0, `rgba(239, 247, 255, ${alpha})`);
              pGlow.addColorStop(0.5, `rgba(58, 223, 255, ${alpha * 0.75})`);
              pGlow.addColorStop(1, 'rgba(58, 223, 255, 0)');
            } else {
              pGlow.addColorStop(0, `rgba(254, 240, 138, ${alpha})`);
              pGlow.addColorStop(0.5, `rgba(178, 130, 255, ${alpha * 0.7})`);
              pGlow.addColorStop(1, 'rgba(120, 85, 255, 0)');
            }
            ctx.fillStyle = pGlow;
            ctx.beginPath();
            ctx.arc(px, py, r * 2.5, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }
      ctx.restore();

      // 4. Thin Flowing Procedural Ribbons around the Hollow Energy Ring
      ctx.save();
      ctx.translate(cx, cy);
      ctx.globalCompositeOperation = 'lighter';

      const ribbons = [
        {
          // Primary Violet Ribbon (#7855FF)
          stroke: isError
            ? 'rgba(244, 63, 94, 0.78)'
            : isConfirming
            ? 'rgba(245, 158, 11, 0.76)'
            : 'rgba(120, 85, 255, 0.84)',
          glow: isError ? '#F43F5E' : isConfirming ? '#F59E0B' : '#7855FF',
          width: 2.6,
          freqA: 3,
          freqB: 5,
          speed: 1.6,
          phase: 0,
          radiusMul: isTranscribing ? 0.95 : 0.99,
          bandWeight: bands.lowBand,
        },
        {
          // Soft Purple Ribbon (#B282FF)
          stroke: isError
            ? 'rgba(251, 146, 60, 0.72)'
            : isSuccess
            ? 'rgba(58, 223, 255, 0.82)'
            : 'rgba(178, 130, 255, 0.76)',
          glow: isSuccess ? '#3ADFFF' : '#B282FF',
          width: 1.9,
          freqA: 4,
          freqB: 3,
          speed: -2.0,
          phase: 1.3,
          radiusMul: isTranscribing ? 0.96 : 1.01,
          bandWeight: bands.midBand,
        },
        {
          // Deep Blue Structural Ribbon (#245FFF)
          stroke: 'rgba(36, 95, 255, 0.80)',
          glow: '#245FFF',
          width: 3.1,
          freqA: 2,
          freqB: 6,
          speed: 1.2,
          phase: 2.5,
          radiusMul: 0.96,
          bandWeight: bands.lowBand,
        },
        {
          // Restrained JARVIS Desktop Cyan Accent Ribbon (#3ADFFF)
          stroke: `rgba(58, 223, 255, ${
            isSuccess ? 0.92 : isExecuting || isThinking ? 0.78 : 0.46
          })`,
          glow: '#3ADFFF',
          width: 1.5,
          freqA: 5,
          freqB: 4,
          speed: -2.4,
          phase: 3.8,
          radiusMul: isTranscribing ? 0.94 : 1.0,
          bandWeight: bands.highBand,
        },
        {
          // Subtle Warm/Lavender Rim Filament
          stroke: isConfirming
            ? 'rgba(251, 191, 36, 0.75)'
            : 'rgba(239, 247, 255, 0.45)',
          glow: isConfirming ? '#FBBF24' : '#B282FF',
          width: 1.2,
          freqA: 3,
          freqB: 7,
          speed: 2.2,
          phase: 5.0,
          radiusMul: 0.995,
          bandWeight: bands.midBand,
        },
      ];

      const segments = 128;
      for (const rib of ribbons) {
        ctx.strokeStyle = rib.stroke;
        ctx.lineWidth = rib.width * (1 + rib.bandWeight * 0.35);
        ctx.shadowColor = rib.glow;
        ctx.shadowBlur = 10 + bands.gatedEnergy * 12;

        ctx.beginPath();
        for (let s = 0; s <= segments; s++) {
          const idx = s % segments;
          const theta = (idx / segments) * Math.PI * 2;
          const harmonic = computeRingHarmonics(
            theta + rib.phase,
            timeFactor * (rib.speed * 0.42),
            curState,
            bands.gatedEnergy
          );

          // Brighter, slightly thicker ribbon convergence along the bottom edge (theta near PI/2)
          const bottomBias = 1 + Math.max(0, Math.sin(theta)) * 0.25;
          const waveA =
            Math.sin(theta * rib.freqA + timeFactor * rib.speed + rib.phase) *
            ringRadius *
            0.036 *
            (0.35 + dynamics.ribbonAmplitude) *
            bottomBias;
          const waveB =
            Math.cos(theta * rib.freqB - timeFactor * rib.speed * 0.75) *
            ringRadius *
            0.024 *
            (0.35 + dynamics.ribbonAmplitude);

          // Inward pull during transcribing state
          const inwardPull = isTranscribing
            ? -Math.abs(Math.sin(timeFactor * 3 + theta * 2)) * ringRadius * 0.035
            : 0;

          const r =
            ringRadius * rib.radiusMul +
            waveA +
            waveB +
            harmonic * (ringRadius / 150) * 0.55 +
            inwardPull;

          const x = Math.cos(theta) * r;
          const y = Math.sin(theta) * r;
          if (s === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.stroke();
      }

      // 5. State-Specific Traveling Highlights (Thinking / Executing / Success)
      if (isThinking) {
        // Smooth orbiting highlight arc
        const orbitAngle = timeFactor * 2.8;
        ctx.strokeStyle = '#3ADFFF';
        ctx.shadowColor = '#3ADFFF';
        ctx.shadowBlur = 16;
        ctx.lineWidth = 3.2;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(0, 0, ringRadius * 0.99, orbitAngle, orbitAngle + Math.PI * 0.45);
        ctx.stroke();
      } else if (isExecuting) {
        // Controlled traveling dual pulses while a tool runs
        for (let p = 0; p < 2; p++) {
          const pulseA = timeFactor * 3.4 + p * Math.PI;
          ctx.strokeStyle = p === 0 ? '#3ADFFF' : '#7855FF';
          ctx.shadowColor = '#3ADFFF';
          ctx.shadowBlur = 14;
          ctx.lineWidth = 3.0;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.arc(0, 0, ringRadius * 0.98, pulseA, pulseA + Math.PI * 0.28);
          ctx.stroke();
        }
      } else if (isSuccess) {
        // Short cyan settling ring highlight
        ctx.strokeStyle = 'rgba(58, 223, 255, 0.75)';
        ctx.shadowColor = '#3ADFFF';
        ctx.shadowBlur = 18;
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.arc(0, 0, ringRadius * 1.01, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.restore();

      const frameDelay = curState === 'idle' || isReduced ? 45 : 38;
      timerId = window.setTimeout(() => {
        render(performance.now());
      }, frameDelay);
    };

    render(performance.now());

    return () => {
      window.clearTimeout(timerId);
      window.removeEventListener('resize', handleResize);
    };
  }, [micAnalyserRef, playbackAnalyserRef, simulatedVoiceEnergyRef]);

  return (
    <div
      onClick={onRingClick}
      className="relative flex items-center justify-center w-[340px] h-[340px] sm:w-[400px] sm:h-[400px] cursor-pointer select-none"
    >
      <canvas
        ref={canvasRef}
        data-testid="jarvis-core-canvas"
        aria-label={`JARVIS energy ring in ${state} state`}
        className="w-full h-full transition-transform duration-200 active:scale-98"
      />
    </div>
  );
};
